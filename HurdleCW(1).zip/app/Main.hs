module Main where

import CLI

main :: IO ()
main = runCLI