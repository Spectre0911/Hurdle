# hurdle

This repository contains the skeleton code for CS141 Functional Programming coursework 1.

Please read the specification IN FULL before attempting to write your solution.
